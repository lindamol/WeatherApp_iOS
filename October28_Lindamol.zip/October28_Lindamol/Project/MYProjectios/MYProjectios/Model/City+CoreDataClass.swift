//
//  City+CoreDataClass.swift
//  MYProjectios
//
//  Created by user203935 on 10/26/21.
//
//

import Foundation
import CoreData

@objc(City)
public class City: NSManagedObject {

}
