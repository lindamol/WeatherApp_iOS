//
//  ApiKey.swift
//  MYProjectios
//
//  Created by user203935 on 10/26/21.
//

import Foundation
let apiKey = "046c55cc85eff8252b1022c169172b29"
