//
//  Model.swift
//  MYProjectios
//
//  Created by user203935 on 10/25/21.
//

//http://gd.geobytes.com/AutoCompleteCity?q=Toronto&callback=
//["Toronto, KS, United States","Toronto, OH, United States","Toronto, ON, Canada","Toronto, SD, United States"]

import Foundation
//class Model{
//    static var Mshared = Model()
//    private init(){}
//
//var Citylist: [String] = []
//struct CityResult : Codable {
//    var cityname : [String]
//}
//}
